#include "mex.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "m_utils.h"
#include "m_malloc.h"
#include "m_TreeNode1b.h"


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){   
   /* check for the proper no. of input and outputs */
   if (nrhs != 2)
   mexErrMsgTxt("2 input arguments are required");
   if (nlhs>1)
   mexErrMsgTxt("Too many outputs");

   /* Get the no. of dimentsions and size of each dimension in the input 
   array */
   const int *sizeDimUnary = mxGetDimensions(prhs[0]);
   const int *sizeDimHist = mxGetDimensions(prhs[1]);

   /* Get the dimensions of the input image */
   int rows = sizeDimUnary[0]; 
   int cols = sizeDimUnary[1]; 
   int histSize = sizeDimHist[0];

   int Output = 0;

   /* Get the pointers to the input Data */  
   double *ImAssignPtr = mxGetPr(prhs[0]);
   double *weightsPtr = mxGetPr(prhs[1]);    
   
   /* create matrices */
   int **ImAssign;
   double *weights;  

   weights = buildVector<double>(histSize);
   ImAssign = buildMatrix<int>(rows, cols);

   // Assign the data targetHist
   for (int k=0; k<histSize; k++){
      weights[k] = (double) (*weightsPtr);
      weightsPtr++;
   }

   // Assign the data for: Im1Assign Im1Init Label1
   for (int j=0; j<cols; j++){
      for (int i=0; i<rows; i++){
         ImAssign[i][j] = ((int) (*ImAssignPtr));
         ImAssignPtr++;  
      }
   }
   /*if (!isImAssignGood(ImAssign, rows, cols)){
      mexErrMsgTxt("ImAssign, 1st agrument must be matrix of positive integers");
   }*/

   if (Output){
      printf("rows: %d, cols: %d, histSize: %d \n", rows, cols, histSize);
   }
   Window bestBB = findBox1b(ImAssign, rows, cols, weights, histSize);

   /* Create the outGoing Array  */
   plhs[0] = mxCreateNumericMatrix(1, 4, mxDOUBLE_CLASS, mxREAL);   
   double *labelOutPtr = mxGetPr(plhs[0]); 
   
   labelOutPtr[0] = (double) (bestBB.ul_x + 1);
   labelOutPtr[1] = (double) (bestBB.ul_y + 1);
   labelOutPtr[2] = (double) (bestBB.lr_x + 1);
   labelOutPtr[3] = (double) (bestBB.lr_y + 1);
   destroyMatrix<int>(ImAssign, rows, cols);
   destroyVector<double>(weights, histSize);   
} 
  