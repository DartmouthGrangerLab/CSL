#include <iostream>
#include <cmath>
#include <queue>
#include <string>
#include <sstream>
#include <fstream>
#include "m_utils.h"
#include "m_malloc.h"
#include "m_TreeNode1b.h"
#include "m_BranchBound.cpp"
#include "m_tests.h"

void test1b_1(){
   int imH1 = 3;
   int imW1 = 4;
   
   int nHistBin = 2;
   int nTest = 5;

   int ***imAssign1 = buildArrayThree<int>(imH1, imW1, nTest);
   double weights[] = {10, -1};
   Window *expBBoxes = new Window[nTest];
   
   int i = 0;
   imAssign1[0][0][i] = 1; imAssign1[1][0][i] = 1; imAssign1[2][0][i] = 1;
   imAssign1[0][1][i] = 2; imAssign1[1][1][i] = 2; imAssign1[2][1][i] = 2;
   imAssign1[0][2][i] = 2; imAssign1[1][2][i] = 2; imAssign1[2][2][i] = 2;
   imAssign1[0][3][i] = 1; imAssign1[1][3][i] = 1; imAssign1[2][3][i] = 1;

   expBBoxes[i] = Window(1,0,2,2);

   i = 1;
   imAssign1[0][0][i] = 1; imAssign1[1][0][i] = 1; imAssign1[2][0][i] = 1;
   imAssign1[0][1][i] = 2; imAssign1[1][1][i] = 2; imAssign1[2][1][i] = 2;
   imAssign1[0][2][i] = 2; imAssign1[1][2][i] = 2; imAssign1[2][2][i] = 1;
   imAssign1[0][3][i] = 1; imAssign1[1][3][i] = 1; imAssign1[2][3][i] = 1;

   expBBoxes[i] = Window(1,0,2,1);

   i = 2;
   imAssign1[0][0][i] = 1; imAssign1[1][0][i] = 1; imAssign1[2][0][i] = 1;
   imAssign1[0][1][i] = 1; imAssign1[1][1][i] = 2; imAssign1[2][1][i] = 2;
   imAssign1[0][2][i] = 2; imAssign1[1][2][i] = 2; imAssign1[2][2][i] = 1;
   imAssign1[0][3][i] = 1; imAssign1[1][3][i] = 1; imAssign1[2][3][i] = 1;

   expBBoxes[i] = Window(1,1,2,1);

   i = 3;
   imAssign1[0][0][i] = 1; imAssign1[1][0][i] = 1; imAssign1[2][0][i] = 1;
   imAssign1[0][1][i] = 1; imAssign1[1][1][i] = 2; imAssign1[2][1][i] = 2;
   imAssign1[0][2][i] = 2; imAssign1[1][2][i] = 1; imAssign1[2][2][i] = 1;
   imAssign1[0][3][i] = 1; imAssign1[1][3][i] = 1; imAssign1[2][3][i] = 2;

   expBBoxes[i] = Window(1,1,1,2);

   i = 4;
   imAssign1[0][0][i] = 1; imAssign1[1][0][i] = 2; imAssign1[2][0][i] = 1;
   imAssign1[0][1][i] = 2; imAssign1[1][1][i] = 2; imAssign1[2][1][i] = 2;
   imAssign1[0][2][i] = 1; imAssign1[1][2][i] = 2; imAssign1[2][2][i] = 1;
   imAssign1[0][3][i] = 1; imAssign1[1][3][i] = 2; imAssign1[2][3][i] = 2;

   expBBoxes[i] = Window(0,1,3,1);


   int **im1 = buildMatrix<int>(imH1, imW1);
            
   for (int k= 0; k < nTest; k++){
      cout << "==============Testing test1b_1." << k << endl;
      cout << "image 1: " << endl;
      for (int i = 0; i< imH1; i++){
         for (int j= 0; j < imW1; j++){
            im1[i][j] = imAssign1[i][j][k];
            printf("%2d ", im1[i][j]);
         }      
         cout << endl;
      }
      

      int ***integralIms1 = cmpIntegralIms(im1, imH1, imW1, nHistBin);
      Window bestBBox = findBox1b(im1, imH1, imW1, weights, nHistBin);
      int *hist1_best = bestBBox.getHist(integralIms1, nHistBin);
      double energy_best = cmpEnergy2(hist1_best, weights, nHistBin);

      cout << "Best window " << bestBBox.str()  
           << ", energy: " << energy_best << endl;      

      int *hist1_exp = expBBoxes[k].getHist(integralIms1, nHistBin);
      double energy_exp = cmpEnergy2(hist1_exp, weights, nHistBin);

      if (energy_best < energy_exp){
         cout << "WARNING: expected energy is bigger than returned energy" << endl;
      } else if (energy_best > energy_exp){
         cout << "FAILED, expected BBoxes: " << expBBoxes[k].str() << endl;
      } else {
         cout << "PASSED" << endl;
      }
      destroyArrayThree<int>(integralIms1, imH1, imW1, nHistBin);
      destroyVector<int>(hist1_best, nHistBin);
      destroyVector<int>(hist1_exp, nHistBin);
      cout << endl; 
   }
}