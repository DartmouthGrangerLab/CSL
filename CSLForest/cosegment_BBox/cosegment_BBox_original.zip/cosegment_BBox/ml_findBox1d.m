function bestBox = ml_findBox1d(imAssigns, targetHists, binWeightss, ...
    nHistBins, C, tolFac, knownBest)
% function bestBox = ml_findBox1d(imAssigns, targetHists, binWeightss, ...
%    C, tolFac, knownBest)
% Find a rectangle with the histogram that best matches the target hisgoram
% The energy that this minimize is:
%   sum_ij {binWeights(i,j)*[|hist(i,j) -targetHist(i,j)| -C*(hist(i,j) + targetHist(i,j)]}
% Inputs:
%   imAssigns: a imH*imW*nHistType matrix for histogram bin assignments 
%       of pixels, entries must be positive integers
%   targetHists: a k*nHistType for the target histograms
%   binWeightss: a k*nHistType matrix of non-negative weights for histogram bins. 
%   C: A number from 0 to 1, tradeoff between perfect histogram matching and
%       the size of the sub-window. 
%   tolFac: for stopping early. tolFac is from 0 to 1. 
%       tolFactor = 0: stop when global optimum is reach
%       tolFac > 0: stop when the difference between the global optimum
%           and the best known is < tolFac of the best known value.
%   knownBest: find the subwindow with the energy smaller than this value
%       if no such subwindow exists, the algorithm returns an arbitary box.
%       The default value is infinity.
% Output:
%   bestBox: a 4*1 vector for the left, top, right, bottom of the rectangle
% By: Minh Hoai Nguyen (minhhoai@gmail.com)
% Date: 30 Aug 2008


if ~exist('binWeightss', 'var') || isempty(binWeightss)
    binWeightss = ones(size(targetHists));
end

if ~exist('C', 'var') || isempty(C)
    C = 0.2;
end

if ~exist('tolFac', 'var') || isempty(tolFac)
    tolFac = 0.1;
end;

if ~exist('knownBest', 'var') || isempty(knownBest)
    knownBest = inf;
end;

% check the inputs
if sum(imAssigns(:) <= 0) > 0
    error('ml_findBox1d.m: entries of imAssign should be positive integers');
end

if sum(size(targetHists) ~= size(binWeightss))
    error('ml_findBox1d.m: targetHists and binWeightss must have the same size');
end

if (C > 1 ) || ( C < 0)
    error('ml_findBox1a.m: C must be from 0 to 1');
end;

if (tolFac > 1) || (tolFac < 0)
    error('ml_findBox1a.m: tolFac must be from 0 to 1');
end;

bestBox = m_mexFindBox1d(imAssigns, targetHists, binWeightss, ...
    nHistBins, C, tolFac, knownBest);

