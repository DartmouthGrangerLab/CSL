#include <iostream>
#include <cmath>
#include <queue>
#include <string>
#include <sstream>
#include <fstream>
#include "m_utils.h"
#include "m_malloc.h"
#include "m_TreeNode1c.h"
#include "m_BranchBound.cpp"
#include "m_tests.h"

void test1c_1(){
   int imH = 3;
   int imW = 4;   
   
   int** imAssign = buildMatrix<int>(imH, imW);
   for (int i = 0;i< imH; i++){
      for (int j= 0; j < imW-1; j++){
         imAssign[i][j] = j+1;
         cout << imAssign[i][j] << " ";
      }
      imAssign[i][imW-1] = 1;
      cout << imAssign[i][imW-1] << endl;
   }

   cout << endl << "Integral images " << endl;
   
   int nHistBin = 3;
   double *binWeights = buildVector<double>(nHistBin);
   binWeights[0] = 1;
   binWeights[1] = 1;
   binWeights[2] = 1;

   int*** integralIms = cmpIntegralIms(imAssign, imH, imW, nHistBin);
   
   for (int k=0; k < nHistBin; k++){
      for (int i=0; i < imH; i++){
         for (int j=0; j < imW; j++){
            printf("%d ", integralIms[i][j][k]);
         }
         printf("\n");
      }
      printf("\n\n");
   }

   double C = 0.2;
   
   int nTest = 17;

   int nLevel = 1;
   int nBranch = 4;
   double *levelWeights = buildVector<double>(nLevel + 1);
   levelWeights[0] = 1;
   levelWeights[1] = 0.5;
   
   int ***targets = buildArrayThree<int>(nTest, (int)pow((double)nBranch, nLevel), nHistBin);
   int **expects = buildMatrix<int>(nTest, 4);
   int i;
   
   i = 0; 
   targets[i][0][0] = 0; targets[i][0][1] = 1; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 1;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 1;
   expects[i][0] = 1; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 1;
   
   i = 1; 
   targets[i][0][0] = 2; targets[i][0][1] = 2; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 2; targets[i][2][1] = 0; targets[i][2][2] = 2;
   targets[i][3][0] = 1; targets[i][3][1] = 0; targets[i][3][2] = 1;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 2;

   i = 2; 
   targets[i][0][0] = 2; targets[i][0][1] = 2; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 2;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 1;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 2;

   i = 3; 
   targets[i][0][0] = 0; targets[i][0][1] = 2; targets[i][0][2] = 2;
   targets[i][1][0] = 0; targets[i][1][1] = 1; targets[i][1][2] = 1;
   targets[i][2][0] = 2; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 1; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 1; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 2;

   i = 4; 
   targets[i][0][0] = 1; targets[i][0][1] = 1; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 1; targets[i][2][1] = 0; targets[i][2][2] = 1;
   targets[i][3][0] = 1; targets[i][3][1] = 0; targets[i][3][2] = 1;
   expects[i][0] = 0; expects[i][1] = 1; expects[i][2] = 3; expects[i][3] = 2;

   i = 5; 
   targets[i][0][0] = 0; targets[i][0][1] = 1; targets[i][0][2] = 1;
   targets[i][1][0] = 0; targets[i][1][1] = 1; targets[i][1][2] = 1;
   targets[i][2][0] = 1; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 1; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 1; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 1;

   i = 6; 
   targets[i][0][0] = 0; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = -1; expects[i][1] = -1; expects[i][2] = -1; expects[i][3] = -1;

   i = 7; 
   targets[i][0][0] = 1; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 1; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 1; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 0; expects[i][3] = 2;

   

   i = 8; 
   targets[i][0][0] = 2; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 0; expects[i][3] = 2;

   i = 9; 
   targets[i][0][0] = 1; targets[i][0][1] = 1; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 1; targets[i][2][1] = 0; targets[i][2][2] = 1;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 0;


   i = 10; 
   targets[i][0][0] = 1; targets[i][0][1] = 1; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 1;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 0;

   i = 11; 
   targets[i][0][0] = 1; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 0; expects[i][3] = 0;
   
   i = 12; 
   targets[i][0][0] = 1; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 1; targets[i][2][2] = 0;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 1; expects[i][3] = 1;

   i = 13; 
   targets[i][0][0] = 2; targets[i][0][1] = 2; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 2;
   targets[i][3][0] = 0; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 2;

   i = 14; 
   targets[i][0][0] = 2; targets[i][0][1] = 2; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 2;
   targets[i][3][0] = 0; targets[i][3][1] = 1; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 2;

   i = 15; 
   targets[i][0][0] = 2; targets[i][0][1] = 2; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 1; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 2;
   targets[i][3][0] = 10; targets[i][3][1] = 1; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 2;

   i = 15; 
   targets[i][0][0] = 2; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 2; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 2; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 2; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 0; expects[i][3] = 2;

   i = 16; 
   targets[i][0][0] = 1; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 0; targets[i][1][2] = 0;
   targets[i][2][0] = 0; targets[i][2][1] = 0; targets[i][2][2] = 0;
   targets[i][3][0] = 1; targets[i][3][1] = 0; targets[i][3][2] = 0;
   expects[i][0] = 3; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 1;

   for (i=0; i<nTest; i++){
      cout << "=========> Testing 13." << i << endl;
      HistTree targetHists(targets[i], nBranch, nLevel, nHistBin, levelWeights);
      targetHists.setEmptyWinE(binWeights);
      /*Window win1(3,0,3,0);
      Window win2(3,2,3,2);
      TreeNode5 rootNode(WindowPair(win1, win2));
      rootNode.cmpBnds(integralIms, &targetHists, binWeights, nHistBin, C);
      cout << "lb: " << rootNode.lb << ", ub: " << rootNode.ub << endl;*/

      double returnEnergy;
      Window bestWin = findBox1c(imAssign, imH, imW, &targetHists, binWeights, 
         nHistBin, C, 0,  100000, &returnEnergy);
      double energy_best = targetHists.cmpE(bestWin, integralIms, binWeights, nHistBin, C); 




      cout << "Best window " << bestWin.str() << ", returned energy: " << returnEnergy << 
         ", energy: " << energy_best << endl;
      
      Window expWin(expects[i][0], expects[i][1], expects[i][2], expects[i][3]);
      if (bestWin == expWin){
         cout << "PASSED" << endl;
      } else {
         double energy_exp = targetHists.cmpE(expWin, integralIms, binWeights, nHistBin, C); 
         
         if (energy_exp > energy_best){
            cout << "WARNING: expected energy is bigger the returned energy" << endl;
         } else if (energy_exp < energy_best){
            cout << "FAILED" << endl;
            printf("   Expected window ul_x: %d, ul_y: %d, lr_x: %d, lr_y: %d\n", 
               expects[i][0], expects[i][1], expects[i][2], expects[i][3]);
            printf("   expected energy: %f\n", energy_exp);
         } else {
            cout << "PASSED" << endl;
         }
      }
      cout << endl;
   }
   destroyArrayThree<int>(targets, nTest, (int)pow((double)nBranch, nLevel), nHistBin);
   destroyMatrix<int>(expects, nTest, nHistBin);
   destroyArrayThree<int>(integralIms, imH, imW, nHistBin);
   destroyMatrix<int>(imAssign, imH, imW);
   destroyVector<double>(binWeights, nHistBin);
   destroyVector<double>(levelWeights, nLevel+1);
}


void test1c_2(){
   char *fileName = "../test1c_2_data.txt";
   //char *fileName = "../test1c_2_data2.txt";
   fstream myfile;
   myfile.open(fileName, fstream::in);
   int nTest;   
   string tmpStr;
   myfile >> nTest;

   for (int k=0; k < nTest; k++){
      myfile >> tmpStr;
      cout << "==========Testing test1c_2." << k << endl;
      int imH, imW, nHistBin;
      myfile >> imH >> imW >> nHistBin;

      //reading matrix
      int **imAssign = buildMatrix<int>(imH, imW);
      for (int i =0; i < imH; i++){
         for (int j = 0; j < imW; j++){
            myfile >> imAssign[i][j];
            printf("%2d ", imAssign[i][j]);
         }
         cout << endl;
      };

      //reading bin weights
      cout << "Bin weights" << endl;
      double *binWeights = buildVector<double>(nHistBin);      
      for (int i= 0; i < nHistBin; i++){
         myfile >> binWeights[i];
         cout << binWeights[i] << " ";
      }
      cout << endl;

      int nBranch, nLevel;
      myfile >> nBranch >> nLevel;
      //reading level weights
      cout << "level weights " << endl;
      double *levelWeights = buildVector<double>(nLevel + 1);
      for (int i = 0; i <= nLevel; i++){
         myfile >> levelWeights[i]; 
         cout << levelWeights[i] << " ";
      }
      cout << endl;

      double C;
      myfile >> C;

      //reading target histograms.
      int **targets = buildMatrix<int>((int)pow((double)nBranch, nLevel), nHistBin);
      cout << "Target " << endl;
      for (int i = 0; i < (int)pow((double)nBranch, nLevel); i++){
         for (int j=0; j < nHistBin; j++){
            myfile >> targets[i][j];
            cout << targets[i][j] << " ";
         }
         cout << endl;
      }

      //reading expected window
      int *expects = buildVector<int>(4);
      for (int i = 0; i < 4; i++){
         myfile >> expects[i];
      }

      cout << endl << "Integral Images " << endl;
      int*** integralIms = cmpIntegralIms(imAssign, imH, imW, nHistBin);   
      for (int k=0; k < nHistBin; k++){
         for (int i=0; i < imH; i++){
            for (int j=0; j < imW; j++){
               printf("%3d ", integralIms[i][j][k]);
            }
            printf("\n");
         }
         printf("\n\n");
      }

      cout << "imH: " << imH << ", imW: " << imW << ", nBranch: " << nBranch << ", nLevel: " << nLevel
         << ", C: " << C << endl;

      //HistTree targetHists(targets, 2, 2, nHistBin, levelWeights);
      //cout << "done creating histTree " << endl;
      HistTree targetHists(targets, nBranch, nLevel, nHistBin, levelWeights);
      //cout << "Hhaha nBranch at the end " <<  targetHists.branches[0]->branches[0]->nBranch << endl;
      targetHists.setEmptyWinE(binWeights);

      double returnEnergy;
      Window bestWin = findBox1c(imAssign, imH, imW, &targetHists, binWeights, 
         nHistBin, C, 0, 100000, &returnEnergy);
      double energy_best = targetHists.cmpE(bestWin, integralIms, binWeights, nHistBin, C); 

      cout << "Best window " << bestWin.str() << ", energy: " << energy_best << endl;
      
      Window expWin(expects[0], expects[1], expects[2], expects[3]);
      if (bestWin == expWin){
         cout << "PASSED" << endl;
      } else {
         double energy_exp = targetHists.cmpE(expWin, integralIms, binWeights, nHistBin, C); 
         
         if (energy_exp > energy_best){
            cout << "WARNING: expected energy is bigger the returned energy" << endl;
         } else if (energy_exp < energy_best){
            cout << "FAILED" << endl;
            printf("   Expected window ul_x: %d, ul_y: %d, lr_x: %d, lr_y: %d\n", 
               expects[0], expects[1], expects[2], expects[3]);
            printf("   expected energy: %f\n", energy_exp);
         } else {
            cout << "PASSED" << endl;
         }
      }
      cout << endl;
      destroyVector<double>(levelWeights, nLevel + 1);
      destroyMatrix<int>(targets, (int)pow((double)nBranch, nLevel), nHistBin);
      destroyVector<int>(expects, 4);
      destroyArrayThree<int>(integralIms, imH, imW, nHistBin);
      destroyMatrix<int>(imAssign, imH, imW);
      destroyVector<double>(binWeights, nHistBin);
   }   
   myfile.close();
}

void test1c_3(){
   char *fileName = "../test1c_3_data.txt";
   fstream myfile;
   myfile.open(fileName, fstream::in);

   double tmp;
   
    
   cout << "==========Testing test1c_3"<< endl;
   int imH, imW, nHistBin;
   myfile >> imH >> imW >> nHistBin;

   //reading matrix
   int **imAssign = buildMatrix<int>(imH, imW);
   for (int i =0; i < imH; i++){
      for (int j = 0; j < imW; j++){
         myfile >> tmp;
         imAssign[i][j] = (int) tmp;
         //printf("%2d ", imAssign[i][j]);
      }
      //cout << endl;
   };

   //reading bin weights
   cout << "Bin weights" << endl;
   double *binWeights = buildVector<double>(nHistBin);      
   for (int i= 0; i < nHistBin; i++){
      myfile >> binWeights[i];
      //cout << binWeights[i] << " ";
   }
   //cout << endl;

   int nBranch, nLevel;
   myfile >> nBranch >> nLevel;
   //reading level weights
   cout << "level weights " << endl;
   double *levelWeights = buildVector<double>(nLevel + 1);
   for (int i = 0; i <= nLevel; i++){
      myfile >> levelWeights[i]; 
      //cout << levelWeights[i] << " ";
   }
   //cout << endl;

   double C;
   myfile >> C;

   //reading target histograms.
   int **targets = buildMatrix<int>((int)pow((double)nBranch, nLevel), nHistBin);
   cout << "Target " << endl;
   for (int i = 0; i < (int)pow((double)nBranch, nLevel); i++){
      for (int j=0; j < nHistBin; j++){
         myfile >> tmp;
         targets[i][j] = (int) tmp;
         //cout << targets[i][j] << " ";
      }
      //cout << endl;
   }


   //cout << endl << "Integral Images " << endl;
   int*** integralIms = cmpIntegralIms(imAssign, imH, imW, nHistBin);   
   
   cout << "imH: " << imH << ", imW: " << imW << ", nBranch: " << nBranch << ", nLevel: " << nLevel
      << ", C: " << C << endl;

   //HistTree targetHists(targets, 2, 2, nHistBin, levelWeights);
   //cout << "done creating histTree " << endl;
   HistTree targetHists(targets, nBranch, nLevel, nHistBin, levelWeights);
   //cout << "Hhaha nBranch at the end " <<  targetHists.branches[0]->branches[0]->nBranch << endl;
   targetHists.setEmptyWinE(binWeights);
   double returnEnergy;
   Window bestWin = findBox1c(imAssign, imH, imW, &targetHists, binWeights, 
      nHistBin, C, 0.3, 100000, &returnEnergy);
   double energy_best = targetHists.cmpE(bestWin, integralIms, binWeights, nHistBin, C); 

   cout << "Best window " << bestWin.str() << ", energy: " << energy_best << endl;
   destroyVector<double>(levelWeights, nLevel + 1);
   destroyMatrix<int>(targets, (int)pow((double)nBranch, nLevel), nHistBin);
   destroyArrayThree<int>(integralIms, imH, imW, nHistBin);
   destroyMatrix<int>(imAssign, imH, imW);
   destroyVector<double>(binWeights, nHistBin);
   
   myfile.close();
};
