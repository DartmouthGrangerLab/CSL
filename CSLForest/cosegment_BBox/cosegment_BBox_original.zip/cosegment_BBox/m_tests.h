#ifndef M_TESTS_H
#define M_TESTS_H

void test1a_1();
void test1a_2();
void test1a_3();
void test1a_4();

void test1b_1();

void test1c_1();
void test1c_2();
void test1c_3();

void test1d_1();

void test2a_1();
void test2a_2();
void test2a_3();

void test2b_1();
void test2b_2();

#endif
