#include "m_TreeNode1d.h"
#include "m_BranchBound.cpp"

using namespace std;

void TreeNode1d::cmpBnds(){
   Window smallestWin = winPair.getSmallestWin();   
   Window largestWin = winPair.getLargestWin();
   double lb_i, ub_i;
   //lb = INF; ub = INF;
   lb = 0; ub = 0;
   for (int i = 0; i < nHistType; i++){      
      int *hist1_min = smallestWin.getHist(integralIms[i], nHistBins[i]);      
      int *hist1_max = largestWin.getHist(integralIms[i], nHistBins[i]);
      lb_i = getLowerBnd1(hist1_min, hist1_max, hist_target[i], weights[i], nHistBins[i], C);
      ub_i = cmpEnergy(hist1_max, hist_target[i], weights[i], nHistBins[i], C);
      //lb = min(lb, lb_i);
      //ub = min(ub, ub_i);
      lb += lb_i;
      ub += ub_i;
      destroyVector<int>(hist1_min, nHistBins[i]);
      destroyVector<int>(hist1_max, nHistBins[i]);
   }
}

int ****TreeNode1d::integralIms = NULL;
int **TreeNode1d::hist_target = NULL;
double **TreeNode1d::weights = NULL;
int *TreeNode1d::nHistBins = NULL;
int TreeNode1d::nHistType = 0;
double TreeNode1d::C = 0;



/**
 * Find the best box in an image matching the multiple target histograms
 *    by minimzing the objective:
 *    sum_ij {weights(j,i)*[|hist(j,i) - hist_target(j,i)| - C*(hist(j,i) + 
 *            hist_target(j,i)]}
 * Inputs:
 *    imAssigns: a 3 dim array for histogram bin assignments, entries should be
 *       positive integers.
 *    imH, imW: heigh and width of the image
 *    hist_target: a 2-dim array for target histogram
 *    weights: a 1-dim array for weights for histogram bins
 *    nHistBin: # of histogram bins
 *    C: tradeoff b/t having good match to the target histogram and the size of the box
 *    tolFactor: tolerence factor for stopping criteria of branch and bound
 *       if tolFactor = 0, run BB until global optimality is known.
 *       the bigger tolFactor, the earlier BB terminates.
 *    knownBest: the solution is known to be better than this value.
 *       branches with the lower bound less than this value is not explored.
 *       if no leaf node has energy smaller than this value, the method
 *       return an arbitrary solution.
 * Output:
 *    A best (within tolerence) rectangle that minimizes the desired energy
 */
Window findBox1d(int ***imAssigns, int imH, int imW, int **hist_target,
                double **weights, int *nHistBins, int nHistType, 
                double C, double tolFactor, double knownBest){  
   
   int ****integralIms = new int***[nHistType];
   for (int i=0; i < nHistType; i++){
      integralIms[i] = cmpIntegralIms(imAssigns[i], imH, imW, nHistBins[i]);
   }   

   Window biggestWin(0,0, imW-1, imH-1);
   TreeNode1d rootNode(WindowPair(biggestWin, biggestWin));
   
   TreeNode1d::integralIms = integralIms;
   TreeNode1d::weights = weights;
   TreeNode1d::hist_target = hist_target;
   TreeNode1d::nHistBins = nHistBins;
   TreeNode1d::nHistType = nHistType;
   TreeNode1d::C = C;
   
   TreeNode1d bestNode = m_branch_bound<TreeNode1d>(rootNode, tolFactor);
 
   for (int i=0; i < nHistType; i++){
      destroyArrayThree<int>(integralIms[i], imH, imW, nHistBins[i]);
   }
   delete [] integralIms;
   return bestNode.winPair.getLargestWin();
}

