#ifndef M_TREENODE1C_H
#define M_TREENODE1C_H
#include <vector>
#include "m_TreeNode1.h"

class HistTree{
public: 
   int nBranch, sqrtBranch, nLevel, *hist, nHistBin;
   bool isLeaf;   
   double weight, emptyWinE;
   double *levelWeights;
   vector<HistTree*> branches;

   // Constructors
   HistTree(int **hists, int nBranch, int nLevel, int nHistBin, double *weights);
   HistTree(){};

   //Destructor
   ~HistTree();

   //functions
   double cmpLb(WindowPair winPair, int ***integralIms, double *binWeights, int nHistBin, double C);
   

   double cmpE(Window win, int ***integralIms, double *binWeights, int nHistBin, double C);

   void setEmptyWinE(double *binWeights);   
protected:
   double cmpLb1(WindowPair winPair, int ***integralIms, double *binWeights, int nHistBin, double C);
   double cmpLb2(WindowPair winPair, int ***integralIms, double *binWeights, int nHistBin, double C);
   void cmpLb2_helper(WindowPair winPair, int ***integralIms, double *binWeights, 
                       int nHistBin, double *levelLbs);
   
};

class TreeNode1c:public TreeNode1{
public:
   static int ***integralIms;
   static HistTree *targetHists;
   static double *binWeights;
   static int nHistBin;
   static double C;

   int sqrtBrnch;
   TreeNode1c(WindowPair winPair_):TreeNode1(winPair_){};
   TreeNode1c():TreeNode1(){};
   
   void cmpBnds();
};

Window findBox1c(int **imAssign, int imH, int imW, 
         HistTree *targetHists, double *weights, 
         int nHistBin, double C, double tolFac, double knownBest, double *energy);

#endif
