#ifndef M_TREENODE1B_H
#define M_TREENODE1B_H
#include "m_TreeNode1.h"

class TreeNode1b:public TreeNode1{
public:
   static int ***integralIms;
   static int nHistBin;
   static double *binWeights;
   TreeNode1b(WindowPair winPair_):TreeNode1(winPair_){};
   TreeNode1b():TreeNode1(){};   
   void cmpBnds();   
};

Window findBox1b(int **imAssign, int imH, int imW, 
                double *weights, int nHistBin); 

#endif
