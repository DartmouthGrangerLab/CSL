#include <iostream>
#include <fstream>
#include <cmath>
#include <queue>
#include <string>
#include <sstream>
#include "m_malloc.h"
#include "m_utils.h"
#include "time.h"
#include "m_TreeNode1c.h"
#include "m_BranchBound.cpp"

/**
 * Create a tree of histograms
 * Inputs:
 *    hists: a 2D array for several pow(nBranch_, nLevel_) histograms.
 *       the tree has nBranch_, the first pow(nBranch_, nLevel_ -1) histograms
 *       is used to built the first branch and so on so forth
 *    nBranch_: number of branches
 *    nLevel_: number of levels
 *    levelWeights: weights for different levels.
 */
HistTree::HistTree(int **hists, int nBranch_, int nLevel_, int nHistBin_, double *levelWeights_){
   nHistBin = nHistBin_;
   nLevel = nLevel_;
   nBranch = nBranch_;
   sqrtBranch = (int)sqrt((double)nBranch);
   levelWeights = levelWeights_;
   weight = levelWeights[0];
   
   if (nLevel == 0){
      isLeaf = true;
      hist = hists[0];  
   } else {
      isLeaf = false;
      hist = buildVector<int>(nHistBin);
      for (int i=0; i < nBranch; i++){
         branches.push_back(new HistTree(&hists[i*(int)pow((double)nBranch, nLevel-1)], 
            nBranch, nLevel - 1, nHistBin, &levelWeights[1]));
         for (int bin=0; bin < nHistBin; bin++){
            hist[bin] += branches[i]->hist[bin];
         }
      }     
   }
};

HistTree::~HistTree(){      
   if (!isLeaf){      
      delete [] hist;         
      for (int i= 0; i < nBranch; i++){         
         delete branches[i];
      }
   }
};

void
HistTree::setEmptyWinE(double *binWeights){
   emptyWinE = 0;
   for (int bin = 0; bin < nHistBin; bin++){
      emptyWinE += binWeights[bin]*hist[bin];
   }
   emptyWinE *=weight;

   if (!isLeaf){
      for (int i=0; i < nBranch; i++){
         branches[i]->setEmptyWinE(binWeights);
         emptyWinE += branches[i]->emptyWinE;
      }
   }
}

double
HistTree::cmpLb(WindowPair winPair, int ***integralIms, double *binWeights, int nHistBin, double C){
   return cmpLb1(winPair, integralIms, binWeights, nHistBin, C);
}

double
HistTree::cmpLb1(WindowPair winPair, int ***integralIms, double *binWeights, int nHistBin, double C){
   Window smallestWin = winPair.getSmallestWin();  
   int *hist_min = smallestWin.getHist(integralIms, nHistBin);
   Window largestWin = winPair.getLargestWin();
   int *hist_max = largestWin.getHist(integralIms, nHistBin);
   double lb = weight*getLowerBnd1(hist_min, hist_max, hist, binWeights, nHistBin, C); 

   destroyVector<int>(hist_min, nHistBin);
   destroyVector<int>(hist_max, nHistBin);
   int x, y;
   if (!isLeaf){
      for (int i=0; i < nBranch; i++){         
         y = i % sqrtBranch + 1;
         x = i/sqrtBranch + 1;
         WindowPair brWinPair = winPair.getSubWinPair(x, y, sqrtBranch, sqrtBranch);
         lb += branches[i]->cmpLb1(brWinPair, integralIms, binWeights, nHistBin, 0);
      }
   }
   return lb;
}

double
HistTree::cmpLb2(WindowPair winPair, int ***integralIms, double *binWeights, int nHistBin, double C){   
   Window smallestWin = winPair.getSmallestWin();  
   int *hist_min = smallestWin.getHist(integralIms, nHistBin);
   Window largestWin = winPair.getLargestWin();
   int *hist_max = largestWin.getHist(integralIms, nHistBin);
   double lb = weight*getLowerBnd1(hist_min, hist_max, hist, binWeights, nHistBin, C);
   destroyVector<int>(hist_min, nHistBin);
   destroyVector<int>(hist_max, nHistBin);
   
   double *levelLbs = buildVector<double>(nLevel + 1);   
   cmpLb2_helper(winPair, integralIms, binWeights, nHistBin, levelLbs);
   
   for (int i = 1; i <= nLevel; i++){
      levelLbs[i] = max(levelLbs[i-1], levelLbs[i]);       
      lb += levelLbs[i]*levelWeights[i];
   };
   destroyVector<double>(levelLbs, nLevel + 1);
   return lb;
}

void
HistTree::cmpLb2_helper(WindowPair winPair, int ***integralIms, double *binWeights, 
                       int nHistBin, double *levelLbs){
   Window smallestWin = winPair.getSmallestWin();  
   int *hist_min = smallestWin.getHist(integralIms, nHistBin);
   Window largestWin = winPair.getLargestWin();
   int *hist_max = largestWin.getHist(integralIms, nHistBin);
   levelLbs[0] += getLowerBnd1(hist_min, hist_max, hist, binWeights, nHistBin, 0);
   
   int x, y;
   if (!isLeaf){
      for (int i=0; i < nBranch; i++){         
         y = i % sqrtBranch + 1;
         x = i/sqrtBranch + 1;
         WindowPair brWinPair = winPair.getSubWinPair(x, y, sqrtBranch, sqrtBranch);
         branches[i]->cmpLb2_helper(brWinPair, integralIms, binWeights, nHistBin, &levelLbs[1]);
      }
   }
   destroyVector<int>(hist_min, nHistBin);
   destroyVector<int>(hist_max, nHistBin);
}


double
HistTree::cmpE(Window win, int ***integralIms, double *binWeights, int nHistBin, double C){
   if (win.lr_x < 0){
      return emptyWinE;
   }
   double energy = 0;
   int *hist_ = win.getHist(integralIms, nHistBin);
   energy = cmpEnergy(hist_, hist, binWeights, nHistBin, C);
   energy *= weight;
   destroyVector<int>(hist_, nHistBin);
   
   int x, y;
   if (!isLeaf){
      for (int i=0; i < nBranch; i++){         
         y = i % sqrtBranch + 1;
         x = i/sqrtBranch + 1;
         Window brWin = win.getSubWin(x, y, sqrtBranch, sqrtBranch);
         energy += branches[i]->cmpE(brWin, integralIms, binWeights, nHistBin, 0);
      }
   }
   return energy;
}

void TreeNode1c::cmpBnds(){
   Window largestWin = winPair.getLargestWin();   
   if (largestWin.ul_x > -1){
      ub = targetHists->cmpE(largestWin, integralIms, binWeights, nHistBin, C);
      lb = targetHists->cmpLb(winPair, integralIms, binWeights, nHistBin, C);
   } else {
      ub = targetHists->emptyWinE;
      lb = targetHists->emptyWinE;
   }
}

int ***TreeNode1c::integralIms = NULL;
HistTree *TreeNode1c::targetHists = NULL;
double *TreeNode1c::binWeights = NULL;
int TreeNode1c::nHistBin = 0;
double TreeNode1c::C = 0;


/**
 * Find the best box in an image matching the pyramid of histograms
 *    like in the pyrmaid matching kernel.
 *    by minimzing the objective:
 *    sum_i {weights(i)*[sum_j levelWeights(j)*|hist_j(i) - hist_target_j(i)| 
 *           - C*(hist_1(i) + hist_target_1(i)]}
 * Inputs:
 *    imAssign: a 2 dim array for histogram bin assignments, entries should be
 *       positive integers.
 *    imH, imW: heigh and width of the image
 *    targetHists: a HistTree for target pyramid of histograms 
 *    weights: a 1-dim array for weights for histogram bins
 *    nHistBin: # of histogram bins
 *    C: tradeoff b/t having good match to the target histogram and the size of the box
 *    tolFactor: tolerence factor for stopping criteria of branch and bound
 *       if tolFactor = 0, run BB until global optimality is known.
 *       the bigger tolFactor, the earlier BB terminates.
 *    knownBest: the solution is known to be better than this value.
 *       branches with the lower bound less than this value is not explored.
 *       if no leaf node has energy smaller than this value, the method
 *       return an arbitrary solution.
 *    energy: the energy of the returned output.
 * Output:
 *    A best (within tolerence) rectangle that matches the pyramid of histograms.
 */
Window findBox1c(int **imAssign, int imH, int imW, 
         HistTree *targetHists, double *weights, 
         int nHistBin, double C, double tolFac, double knownBest, double *energy){

   int ***integralIms = cmpIntegralIms(imAssign, imH, imW, nHistBin);
   TreeNode1c::integralIms = integralIms;
   TreeNode1c::C = C;
   TreeNode1c::binWeights = weights;
   TreeNode1c::nHistBin = nHistBin;
   TreeNode1c::targetHists = targetHists;

   Window biggestWin(0,0, imW-1, imH-1);
   TreeNode1c rootNode(WindowPair(biggestWin, biggestWin));
   TreeNode1c bestNode = m_branch_bound<TreeNode1c>(rootNode, tolFac);
   
   energy[0] = targetHists->cmpE(bestNode.winPair.getLargestWin(), 
      integralIms, weights, nHistBin, C); 
   destroyArrayThree<int>(integralIms, imH, imW, nHistBin);
   return bestNode.winPair.getLargestWin();
}
