#include <iostream>
#include <cmath>
#include <queue>
#include <string>
#include <sstream>
#include <fstream>
#include "m_utils.h"
#include "m_malloc.h"
#include "m_tests.h"
#include "m_BranchBound.cpp"
#include "m_TreeNode1.h"
#include "m_TreeNode1a.h"
#include "m_TreeNode1b.h"
#include "m_TreeNode1c.h"
#include "m_TreeNode2a.h"

#ifdef _DEBUG
   #define DEBUG_CLIENTBLOCK   new( _CLIENT_BLOCK, __FILE__, __LINE__)
#else
   #define DEBUG_CLIENTBLOCK
#endif

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif

#define EPS 0.0000000001

using namespace std;


int main(){
   //test1a_1();
   //test1a_2();
   test1a_3();
   //test1a_4();

   //test1b_1();

   //test1c_1();
   //test1c_2();
   //test1c_3();

   //test1d_1();

   //test2a_1();
   //test2a_2();
   //test2a_3();

   //test2b_1();
   //test2b_2();
   
   printf("Done\n");     
   _CrtDumpMemoryLeaks();
   return 0;    
}

