function bestBox = ml_findBox1c(imAssign, targetHists, binWeights, ...
    levelWeights, nBranch, C, tolFac, knownBest)
% function bestBox = ml_findBox1c(imAssign, targetHists, binWeights, ...
%    C, tolFac, knownBest)
% Find a rectangle with the histogram that best matches the pyramid of
% histograms.
% The energy that this minimize is:
%    sum_i {weights(i)*[sum_j levelWeights(j)*|hist_j(i) - hist_target_j(i)| 
%           - C*(hist_1(i) + hist_target_1(i)]}
% Inputs:
%   imAssign: a imH*imW matrix for histogram bin assignments of pixels, 
%       entries must be integers from 1 to k, where k is number of
%       histogram bins
%   targetHists: a nHistBin*(nBranch^(nLevel-1)) column vector for the target
%       histograms
%       Order of histograms are spatially distributed as:
%           e.g. nBranch = 4; nLevel = 2: 
%               [1 3; 
%                2 4];
%           e.g. nBranch = 9; nLevel = 2: 
%               [1 4 7; 
%                2 5 8; 
%                3 6 9];
%           e.g. nBranch = 4; nLevel = 3: 
%               [1 3  9 11; 
%                2 4 10 12; 
%                5 7 13 15; 
%                6 8 14 16]
%   binWeights: a nHistBin*1 vector of non-negative weights for histogram bins. 
%   C: A number from 0 to 1, tradeoff between perfect histogram matching and
%       the size of the sub-window. 
%   tolFac: for stopping early. tolFac is from 0 to 1. 
%       tolFactor = 0: stop when global optimum is reach
%       tolFac > 0: stop when the difference between the global optimum
%           and the best known is < tolFac of the best known value.
%   knownBest: find the subwindow with the energy smaller than this value
%       if no such subwindow exists, the algorithm returns an arbitary box.
%       The default value is infinity.
% Output:
%   bestBox: a 4*1 vector for the left, top, right, bottom of the rectangle
% By: Minh Hoai Nguyen (minhhoai@gmail.com)
% Date: 29 Aug 2008


if ~exist('binWeights', 'var') || isempty(binWeights)
    binWeights = ones(size(targetHists,1), 1);
end

if ~exist('C', 'var') || isempty(C)
    C = 0.2;
end

if ~exist('tolFac', 'var') || isempty(tolFac)
    tolFac = 0.2;
end;

if ~exist('knownBest', 'var') || isempty(knownBest)
    knownBest = inf;
end;

% check the inputs
if size(binWeights, 2) ~= 1
    error('ml_findBox1c.m: binWeights should be a column vector');
end;

nHistBin = size(binWeights, 1);
if sum(imAssign(:) <= 0) > 0
    error('ml_findBox1c.m: entries of imAssign should be positive integers');
end

if sum(imAssign(:) > nHistBin) > 0
    error('ml_findBox1c.m: entries of imAssign must be smaller than the length of binWeights');
end

if (size(targetHists,1) ~= size(binWeights,1))    
    error('ml_findBox1c.m: targetHists and binWeights must have the same height');
end

if (size(levelWeights, 2) > 1)
    error('ml_findBox1c.m: levelWeights should be a column vector');
end;        

if (C > 1 ) || ( C < 0)
    error('ml_findBox1a.m: C must be from 0 to 1');
end;

if (tolFac > 1) || (tolFac < 0)
    error('ml_findBox1a.m: tolFac must be from 0 to 1');
end;

bestBox = m_mexFindBox1c(imAssign, targetHists, binWeights, levelWeights, ...
    nBranch, C, tolFac, knownBest);

