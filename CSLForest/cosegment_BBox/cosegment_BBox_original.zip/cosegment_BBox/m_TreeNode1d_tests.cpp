#include "m_TreeNode1d.h"
#include <iostream>

void test1d_1(){
   int imH = 3;
   int imW = 4;
   int nHistType = 2;
   int ***imAssign = new int**[nHistType];
   double **weights = new double*[nHistType];
   int *nHistBins = buildVector<int>(nHistType);   

   for (int u = 0; u < nHistType; u++){
      nHistBins[u] = 3;
      imAssign[u] = buildMatrix<int>(imH, imW);
      weights[u] = buildVector<double>(nHistBins[u]);
      for (int i = 0; i< imH; i++){
         for (int j= 0; j < imW-1; j++){
            imAssign[u][i][j] = j+1;
            cout << imAssign[u][i][j] << " ";
         }
         imAssign[u][i][imW-1] = 1;
         cout << imAssign[u][i][imW-1] << endl;
      }

      for (int i = 0; i < nHistBins[u]; i++){
         weights[u][i] = 1;
      }
   }

   cout << endl << "Integral images " << endl;
   
   int ****integralIms = new int***[nHistType];
   for (int u=0; u < nHistType; u++){
      integralIms[u] = cmpIntegralIms(imAssign[u], imH, imW, nHistBins[u]);
      printf("Integral image for layer %d\n", u);
      for (int k=0; k < nHistBins[u]; k++){
         for (int i=0; i < imH; i++){
            for (int j=0; j < imW; j++){
               printf("%d ", integralIms[u][i][j][k]);
            }
            printf("\n");
         }
         printf("\n\n");
      }
   }

   

   double C = 0.2;
   
   int nTest = 6;
   int ***targets = new int**[nTest];
   for (int t=0; t < nTest; t++){
      targets[t] = new int*[nHistType];
      for (int u=0; u < nHistType; u++){
         targets[t][u] = buildVector<int>(nHistBins[u]);
      }
   }      
   int **expects = buildMatrix<int>(nTest, 4);
   
   int i;
   i = 0; 
   targets[i][0][0] = 3; targets[i][0][1] = 3; targets[i][0][2] = 0;
   targets[i][1][0] = 3; targets[i][1][1] = 3; targets[i][1][2] = 0;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 1; expects[i][3] = 2;
   
   i = 1; 
   targets[i][0][0] = 6; targets[i][0][1] = 3; targets[i][0][2] = 3;
   targets[i][1][0] = 3; targets[i][1][1] = 3; targets[i][1][2] = 3;   
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 2;
   
   i = 2; 
   targets[i][0][0] = 0; targets[i][0][1] = 0; targets[i][0][2] = 0;
   targets[i][1][0] = 1; targets[i][1][1] = 2; targets[i][1][2] = 0;      
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 1; expects[i][3] = 1;
   
   i = 3; 
   targets[i][0][0] = 0; targets[i][0][1] = 2; targets[i][0][2] = 0;
   targets[i][1][0] = 0; targets[i][1][1] = 2; targets[i][1][2] = 1;      
   expects[i][0] = 1; expects[i][1] = 0; expects[i][2] = 1; expects[i][3] = 1;

   
   i = 4; 
   targets[i][0][0] = 0; targets[i][0][1] = 2; targets[i][0][2] = 2;
   targets[i][1][0] = 1; targets[i][1][1] = 2; targets[i][1][2] = 2;      
   expects[i][0] = 1; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 1;

   i = 5; 
   targets[i][0][0] = 2; targets[i][0][1] = 0; targets[i][0][2] = 2;
   targets[i][1][0] = 3; targets[i][1][1] = 0; targets[i][1][2] = 2;      
   expects[i][0] = 2; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 1;
   
   /*i = 6; targets[i][0] = 0; targets[i][1] = 0; targets[i][2] = 1;
   expects[i][0] = 2; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 0;
   
   i = 7; targets[i][0] = 2; targets[i][1] = 2; targets[i][2] = 2;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 2; expects[i][3] = 1;

   i = 8; targets[i][0] = 3; targets[i][1] = 2; targets[i][2] = 2;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 1;

   i = 9; targets[i][0] = 4; targets[i][1] = 2; targets[i][2] = 2;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 1;

   i = 10; targets[i][0] = 5; targets[i][1] = 2; targets[i][2] = 2;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 1;
   
   i = 11; targets[i][0] = 5; targets[i][1] = 2; targets[i][2] = 3;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 2;

   i = 12; targets[i][0] = 5; targets[i][1] = 3; targets[i][2] = 3;
   expects[i][0] = 0; expects[i][1] = 0; expects[i][2] = 3; expects[i][3] = 2;*/

   for (i=0; i<nTest; i++){
      cout << "=========> Testing 1." << i << endl;
      Window bestWin = findBox1d(imAssign, imH, imW, targets[i], weights, nHistBins, nHistType, C, 0, INF);
      double energy_best = 0;
      double energy_exp = 0;
      Window expWin(expects[i][0], expects[i][1], expects[i][2], expects[i][3]);
      
      for (int u =0; u < nHistType; u++){
         int *hist_best = bestWin.getHist(integralIms[u], nHistBins[u]);
         double tmp = cmpEnergy(hist_best, targets[i][u], weights[u], nHistBins[u], C);
         energy_best = min(energy_best, tmp);
         int *hist_exp = expWin.getHist(integralIms[u], nHistBins[u]);
         tmp = cmpEnergy(hist_exp, targets[i][u], weights[u], nHistBins[u], C);
         energy_exp = min(energy_exp, tmp);
         destroyVector<int>(hist_exp, nHistBins[u]);
         destroyVector<int>(hist_best, nHistBins[u]);
      }

      cout << "Best window " << bestWin.str() << ", energy: " << energy_best << endl;
      
      if (bestWin == expWin){
         cout << "PASSED" << endl;
      } else {        
         if (energy_exp > energy_best){
            cout << "WARNING: expected energy is bigger the returned energy" << endl;
         } else if (energy_exp < energy_best){
            cout << "FAILED" << endl;
            printf("   Expected window ul_x: %d, ul_y: %d, lr_x: %d, lr_y: %d\n", 
               expects[i][0], expects[i][1], expects[i][2], expects[i][3]);
         } else {
            cout << "PASSED" << endl;
         }        
      }
      cout << endl;      
   }

   for (int u = 0; u < nHistType; u++){
      destroyMatrix<int>(imAssign[u], imH, imW);
      destroyVector<double>(weights[u], nHistBins[u]);
      destroyArrayThree<int>(integralIms[u], imH, imW, nHistBins[u]);
   }
   delete [] imAssign;
   delete [] weights;
   delete [] integralIms;

   for (int t=0; t < nTest; t++){
      for (int u=0; u < nHistType; u++){
         destroyVector<int>(targets[t][u], nHistBins[u]);
      }
      delete [] targets[t];
   }
   delete [] targets;
   destroyMatrix<int>(expects, nTest, 4);
   destroyVector<int>(nHistBins, nHistType);
}