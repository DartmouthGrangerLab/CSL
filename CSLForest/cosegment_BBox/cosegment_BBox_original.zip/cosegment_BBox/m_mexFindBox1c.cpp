#include "mex.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "m_utils.h"
#include "m_malloc.h"
#include "m_TreeNode1c.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){ 
   /* check for the proper no. of input and outputs */
   if (nrhs != 8) mexErrMsgTxt("8 input arguments are required");
   if (nlhs>2) mexErrMsgTxt("Too many outputs");
   int Output = 0;
   
   /* Get the no. of dimentsions and size of each dimension in the input 
   array */
   const int *sizeDimUnary = mxGetDimensions(prhs[0]);

   /* Get the dimensions of the input image */
   int rows = sizeDimUnary[0]; 
   int cols = sizeDimUnary[1]; 

   const int *nLevelPtr = mxGetDimensions(prhs[3]);
   int nLevel = nLevelPtr[0] -1 ;

   const int *sizeDimHist = mxGetDimensions(prhs[1]);
   int histSize = sizeDimHist[0];   

   /* Get the pointers to the input Data */  
   double *ImAssignPtr = mxGetPr(prhs[0]);
   double *targetHistPtr = mxGetPr(prhs[1]);    
   double *binWeightsPtr = mxGetPr(prhs[2]);
   double *levelWeightsPtr = mxGetPr(prhs[3]);
   double *branchPtr = mxGetPr(prhs[4]);
   double *CPtr = mxGetPr(prhs[5]);
   double *tolFacPtr = mxGetPr(prhs[6]);
   double *knownBestPtr = mxGetPr(prhs[7]);

   double C = (double) *CPtr;
   double tolFac = (double) *tolFacPtr;
   double knownBest = (double) *knownBestPtr;
   int nBranch = (int) *branchPtr;

   /* create matrices */
   int **ImAssign, **targetHists;  
   double *binWeights, *levelWeights; 
   
   // Assign the data for: ImAssign
   ImAssign    = buildMatrix<int>(rows, cols);
   for (int j=0; j<cols; j++){
      for (int i=0; i<rows; i++){
         ImAssign[i][j] = ((int) (*ImAssignPtr));
         ImAssignPtr++;  
      }
   }

   if (!isImAssignGood(ImAssign, rows, cols)){
      mexErrMsgTxt("ImAssign, 1st agrument must be matrix of positive integers");
   }
   

   // Assign the data bin weights;
   binWeights  = buildVector<double>(histSize);   
   for (int k=0; k<histSize; k++){
      binWeights[k] = (double) (*binWeightsPtr);
      binWeightsPtr++;
   }
   
   //assign the layer weight
   levelWeights = buildVector<double>(nLevel+1);   
   for (int k=0; k <= nLevel; k++){
      levelWeights[k] = (double) *levelWeightsPtr;
      levelWeightsPtr++;
   }
   
   //Assign the target hist
   int nHists = (int)pow((double)nBranch, nLevel);
   targetHists  = buildMatrix<int>(nHists, histSize);
   for (int j=0; j < nHists; j++){
      for (int i=0; i < histSize; i++){
         targetHists[j][i] = (int) *targetHistPtr;
         targetHistPtr++;
      }
   }
   
   HistTree targetHistTree(targetHists, nBranch, nLevel, histSize, levelWeights);
   targetHistTree.setEmptyWinE(binWeights);

   if (Output){
      printf("rows: %d, cols: %d, nBranch: %d, nLevel: %d, C: %f, knownBest: %f \n", 
         rows, cols, nBranch, nLevel, C, knownBest);
   }

   double energy;
   Window bestBB = findBox1c(ImAssign, rows, cols, &targetHistTree, binWeights, 
      histSize, C, tolFac, knownBest, &energy);
   
   if (Output){
      printf("Done\n");
   }

   /* Create the outGoing Array  */
   plhs[0] = mxCreateNumericMatrix(1, 4, mxDOUBLE_CLASS, mxREAL);   
   double *labelOutPtr = mxGetPr(plhs[0]); 
   plhs[1] = mxCreateNumericMatrix(1,1, mxDOUBLE_CLASS, mxREAL);
   double *energyOutPtr = mxGetPr(plhs[1]);
   
   labelOutPtr[0] = (double) (bestBB.ul_x + 1);
   labelOutPtr[1] = (double) (bestBB.ul_y + 1);
   labelOutPtr[2] = (double) (bestBB.lr_x + 1);
   labelOutPtr[3] = (double) (bestBB.lr_y + 1);
   energyOutPtr[0] = energy;

   destroyMatrix<int>(ImAssign, rows, cols);
   destroyMatrix<int>(targetHists, nHists, histSize);   
   destroyVector<double>(binWeights, histSize);
   destroyVector<double>(levelWeights, nLevel+1);
} 
  