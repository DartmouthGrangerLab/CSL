#include "mex.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "m_utils.h"
#include "m_malloc.h"
#include "m_TreeNode1d.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){ 
   /* check for the proper no. of input and outputs */
   if (nrhs != 7)
   mexErrMsgTxt("7 input arguments are required");
   if (nlhs>1)
   mexErrMsgTxt("Too many outputs");

   /* Get the no. of dimentsions and size of each dimension in the input 
   array */
   const int *sizeDimUnary = mxGetDimensions(prhs[0]);

   /* Get the dimensions of the input image */
   int rows = sizeDimUnary[0]; 
   int cols = sizeDimUnary[1]; 

   const int *nHistTypePtr = mxGetDimensions(prhs[1]);
   int nHistType = nHistTypePtr[1];

   int Output = 0;

   /* Get the pointers to the input Data */  
   double *ImAssignPtr = mxGetPr(prhs[0]);
   double *targetHistPtr = mxGetPr(prhs[1]);    
   double *weightsPtr = mxGetPr(prhs[2]);
   double *nHistBinsPtr = mxGetPr(prhs[3]);
   double *CPtr = mxGetPr(prhs[4]);
   double *tolFacPtr = mxGetPr(prhs[5]);
   double *knownBestPtr = mxGetPr(prhs[6]);

   double C = (double) *CPtr;
   double knownBest = (double) *knownBestPtr;
   double tolFac = (double) *tolFacPtr;

   /* create matrices */
   int ***ImAssigns, **targetHists, *nHistBins;     
   double **weights;

   ImAssigns = new int**[nHistType];
   targetHists = new int*[nHistType];
   weights = new double*[nHistType];
   nHistBins = buildVector<int>(nHistType);
   int nHistBin_max = 0;
   for (int u=0; u < nHistType; u++){
      nHistBins[u] = (int) (*nHistBinsPtr);
      nHistBin_max = max(nHistBins[u], nHistBin_max);
      nHistBinsPtr++;
   }

   for (int u=0; u < nHistType; u++){      
      targetHists[u] = buildVector<int>(nHistBins[u]);
      weights[u] = buildVector<double>(nHistBins[u]);
      ImAssigns[u] = buildMatrix<int>(rows, cols);

      // Assign the data targetHist
      for (int k=0; k< nHistBins[u]; k++){
         targetHists[u][k] = (int) (*targetHistPtr);
         weights[u][k] = (double) (*weightsPtr);         
         targetHistPtr++;         
         weightsPtr++;
      }
      for (int k=nHistBins[u]; k < nHistBin_max; k++){
         targetHistPtr++;
         weightsPtr++;
      }

      // Assigne the data for: Im1Assign Im1Init Label1
      for (int j=0; j<cols; j++){
         for (int i=0; i<rows; i++){
            ImAssigns[u][i][j] = ((int) (*ImAssignPtr));            
            ImAssignPtr++;  
         }         
      }      
   }   

   if (Output){
      printf("rows: %d, cols: %d, nHistType: %d, max histSize: %d, C: %f, knownBest: %f \n", 
         rows, cols, nHistType, nHistBin_max, C, knownBest);
   }
   Window bestBB = findBox1d(ImAssigns, rows, cols, targetHists, 
      weights, nHistBins, nHistType, C, tolFac, knownBest);
   if (Output){
      printf("Done\n");
   }


   /* Create the outGoing Array  */
   plhs[0] = mxCreateNumericMatrix(1, 4, mxDOUBLE_CLASS, mxREAL);   
   double *labelOutPtr = mxGetPr(plhs[0]); 
   
   labelOutPtr[0] = (double) (bestBB.ul_x + 1);
   labelOutPtr[1] = (double) (bestBB.ul_y + 1);
   labelOutPtr[2] = (double) (bestBB.lr_x + 1);
   labelOutPtr[3] = (double) (bestBB.lr_y + 1);
   for (int u=0; u < nHistType; u++){
      destroyMatrix<int>(ImAssigns[u], rows, cols);
      destroyVector<int>(targetHists[u], nHistBins[u]);   
      destroyVector<double>(weights[u], nHistBins[u]);
   }
   delete [] ImAssigns;
   delete [] targetHists;
   delete [] weights;
   destroyVector<int>(nHistBins, nHistType);
} 
  