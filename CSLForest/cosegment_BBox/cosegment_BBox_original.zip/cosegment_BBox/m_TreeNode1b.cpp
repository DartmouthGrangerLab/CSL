#include "m_malloc.h"
#include "m_utils.h"
#include "m_BranchBound.cpp"
#include "m_TreeNode1b.h"



void
TreeNode1b::cmpBnds(){
   Window smallestWin = winPair.getSmallestWin();
   int *hist1_min = smallestWin.getHist(integralIms, nHistBin, K);
   Window largestWin = winPair.getLargestWin();
   int *hist1_max = largestWin.getHist(integralIms, nHistBin, K);

   lb = 0;
   for (int i=0; i < nHistBin*K; i++){
      if (binWeights[i] < 0){
         lb += binWeights[i]*hist1_max[i];
      } else {
         lb += binWeights[i]*hist1_min[i];
      }
   }  
   ub = cmpEnergy2(hist1_max, binWeights, nHistBin, K);  

   destroyVector<int>(hist1_min, nHistBin, K);
   destroyVector<int>(hist1_max, nHistBin, K);
}


int ***TreeNode1b::integralIms = NULL;
double *TreeNode1b::binWeights = NULL;
int TreeNode1b::nHistBin = 0;



/**
 * Find the best box in an image that minimizes:
 *    sum_i {weights(i)*hist(i)}
 * This function can be used to find the largest enclosing box.
 * Inputs:
 *    imAssign: a 2 dim array for histogram bin assignments, entries should be
 *       positive integers.
 *    imH, imW: heigh and width of the image
 *    weights: a 1-dim array for weights for histogram bins
 *    nHistBin: # of histogram bins 
 * Output:
 *    A best rectangle that minimizes the desired energy
 */
Window findBox1b(int **imAssign, int imH, int imW, double *weights, int nHistBin){   
   int ***integralIms = cmpIntegralIms(imAssign, imH, imW, nHistBin);
   Window biggestWin(0,0, imW-1, imH-1);
   TreeNode1b rootNode(WindowPair(biggestWin, biggestWin));
   double tolFactor = 0;
   
   TreeNode1b::integralIms = integralIms;
   TreeNode1b::binWeights = weights;
   TreeNode1b::nHistBin = nHistBin;
   
   TreeNode1b bestNode = m_branch_bound<TreeNode1b>(rootNode, tolFactor);
   destroyArrayThree<int>(integralIms, imH, imW, nHistBin);   
   return bestNode.winPair.getLargestWin();
}
