function histo = m_cmpPyramidHists(imAssign, nHistBin, rec, nBranch, nLevel)
    if (nLevel == 0)
        if rec(1) ==0
            histo = zeros(nHistBin, 1);
        else
            mask = zeros(size(imAssign));
            mask(rec(2):rec(4), rec(1):rec(3)) = 1;
            histo = m_cmpRegHist_multi(imAssign, nHistBin, mask);
        end
    else 
        histo = zeros(nHistBin, nBranch^nLevel);
        sz = nBranch^(nLevel-1);
        sqrtBranch = sqrt(nBranch);
        xDev = sqrtBranch;
        yDev = sqrtBranch;
        for x=1:xDev
            for y=1:yDev
                subRec_i = cmpSubWindow(rec, x, y, xDev, yDev);
                histo_i = m_cmpPyramidHists(imAssign, nHistBin, subRec_i, nBranch, nLevel-1);
                histo(:, (1+((y-1) + (x-1)*xDev)*sz):((y + (x-1)*xDev))*sz ) = histo_i;
            end;
        end;
    end;

function subRec = cmpSubWindow(rec, x, y, xDev, yDev)
    ul_x = rec(1);
    ul_y = rec(2);
    lr_x = rec(3);
    lr_y = rec(4);
    subRec(1) = ul_x + ceil((lr_x - ul_x + 1)*(x-1)/xDev);
    subRec(3) = ul_x + ceil((lr_x - ul_x + 1)*x/xDev)  - 1;
    subRec(2) = ul_y + ceil((lr_y - ul_y + 1)*(y-1)/yDev);
    subRec(4) = ul_y + ceil((lr_y - ul_y + 1)*y/yDev) - 1;
    
    if subRec(1) > subRec(3) || subRec(2) > subRec(4)
        subRec = [0 0 0 0];
    end;