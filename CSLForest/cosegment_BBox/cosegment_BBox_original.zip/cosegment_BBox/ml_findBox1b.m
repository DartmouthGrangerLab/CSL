function bestBox = ml_findBox1b(imAssign, binWeights)
% function bestBox = ml_findBox1b(imAssign, binWeights)
% Find a rectangle with the histogram that minimize the weighted sum
%   sum_i {binWeights(i)*hist(i)}
% Inputs:
%   imAssign: a imH*imW matrix for histogram bin assignments of pixels, 
%       entries must be integers from 1 to k, where k is number of
%       histogram bins
%   binWeights: a k*1 vector of weights for histogram bins, weights can be
%       negative
% Output:
%   bestBox: a 4*1 vector for the left, top, right, bottom of the rectangle
% By: Minh Hoai Nguyen (minhhoai@gmail.com)
% Date: 30 Aug 2008

if size(binWeights, 2) ~= 1
    error('binWeights should be a column vector');
end;

nHistBin = size(binWeights, 1);
if sum(imAssign(:) <= 0) > 0
    error('entries of imAssign should be positive integers');
end

if sum(imAssign(:) > nHistBin) > 0
    error('entries of imAssign must be smaller than the length of binWeights');
end

bestBox = m_mexFindBox1b(imAssign, binWeights);

