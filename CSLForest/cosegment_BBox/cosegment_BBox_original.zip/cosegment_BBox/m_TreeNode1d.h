#ifndef M_TREENODE1D_H
#define M_TREENODE1D_H
#include "m_TreeNode1.h"

class TreeNode1d:public TreeNode1{
public:
   static int ****integralIms;
   static int **hist_target;
   static double **weights;
   static int *nHistBins;
   static int nHistType;
   static double C;

   TreeNode1d(WindowPair winPair_):TreeNode1(winPair_){};
   TreeNode1d():TreeNode1(){};
   
   void cmpBnds(); 
};


Window findBox1d(int ***imAssigns, int imH, int imW, int **hist_target,
                double **weights, int *nHistBins, int nHistType, 
                double C, double tolFact, double knownBest);



#endif 